const dishes = [
  { id: 1, name: 'Hakka Noodles', price: 150, image: 'hakka-noodles-recipe.jpg' },
  { id: 2, name: 'Veg Manchurian', price: 180, image: 'download.jpeg' },
  { id: 3, name: 'Fried Rice', price: 130, image: 'fried rice.jpeg' },
  { id: 4, name: 'Spring Rolls', price: 100, image: 'spring.jpeg' },
  { id: 5, name: 'Chilli Paneer', price: 170, image: 'chilli-paneer-starter-recipe1.jpg' },
  { id: 6, name: 'Schezwan Rice', price: 140, image: 'schz rice.jpeg' },
  { id: 7, name: 'Gobi Manchurian', price: 160, image: 'gobi-manchurian-cauliflower-manchurian.jpg' },
  { id: 8, name: 'Dimsums', price: 120, image: 'dimsums.jpeg' },
  { id: 9, name: 'Kung Pao Chicken', price: 210, image: 'kung pao.jpeg' },
  { id: 10, name: 'Sweet Corn Soup', price: 90, image: '025-sweet-corn-vegetable-soup.jpg' },
  { id: 11, name: 'Hot and Sour Soup', price: 95, image: 'hot.jpeg' },
  { id: 12, name: 'Veg Chowmein', price: 110, image: 'noodles.jpeg' },
  { id: 13, name: 'Chicken Momos', price: 160, image: 'momos.jpeg' },
  { id: 14, name: 'Paneer Tikka', price: 200, image: 'paneer tikka.jpeg' },
  { id: 15, name: 'Crispy Baby Corn', price: 125, image: 'baby corn.jpeg' }
];

const counters = {};
const cardsSection = document.getElementById('cards-section');

function renderCards(filter = '') {
  cardsSection.innerHTML = '';
  dishes.forEach(dish => {
    if (dish.name.toLowerCase().includes(filter.toLowerCase())) {
      counters[dish.id] = counters[dish.id] || 0;
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `
        <img src="${dish.image}" alt="${dish.name}" />
        <h3>${dish.name}</h3>
        <div class="price">Price: ₹${dish.price}</div>
        <div class="qty">Items added: <span id="qty${dish.id}">${counters[dish.id]}</span></div>
        <div class="btn-group">
          <button class="add-btn" onclick="addItem(${dish.id})">Add</button>
          <button class="remove-btn" onclick="removeItem(${dish.id})">Remove</button>
        </div>
      `;
      cardsSection.appendChild(card);
    }
  });
}

function addItem(id) {
  counters[id]++;
  document.getElementById(`qty${id}`).textContent = counters[id];
}

function removeItem(id) {
  if (counters[id] > 0) {
    counters[id]--;
    document.getElementById(`qty${id}`).textContent = counters[id];
  }
}

function filterCards() {
  const searchTerm = document.getElementById('search').value;
  renderCards(searchTerm);
}

renderCards();
